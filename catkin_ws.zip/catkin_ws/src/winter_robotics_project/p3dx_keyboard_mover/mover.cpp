#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <sensor_msgs/Joy.h>
#include<iostream>
#include <stdio.h>
#include <unistd.h>
#include <termios.h>


class pioneer
{
public:
  pioneer();

private:
  void joyCallback(const sensor_msgs::Joy::ConstPtr& joy);

  ros::NodeHandle nh_;

  int linear_, angular_;
  double l_scale_, a_scale_;
  ros::Publisher vel_pub_;
  ros::Subscriber joy_sub_;

};


pioneer::pioneer():
  linear_(1),
  angular_(2)
{

  nh_.param("axis_linear", linear_, linear_);
  nh_.param("axis_angular", angular_, angular_);
  nh_.param("scale_angular", a_scale_, a_scale_);
  nh_.param("scale_linear", l_scale_, l_scale_);


  vel_pub_ =nh_.advertise<geometry_msgs::Twist>("/RosAria/cmd_vel",1000);


  joy_sub_ = nh_.subscribe<sensor_msgs::Joy>("joy", 5, &pioneer::joyCallback, this);

}

void pioneer::joyCallback(const sensor_msgs::Joy::ConstPtr& joy)
{
  geometry_msgs::Twist twist;
  twist.angular.z = joy->axes[angular_];
  twist.linear.x = 0.5*joy->axes[linear_];
  auto button = joy->buttons[0];
  if(button == 1) {
        vel_pub_.publish(twist);
        button = joy->buttons[0];
   }
}


int main(int argc, char** argv)
{
  ros::init(argc, argv, "Pioneer");
  pioneer Pioneer;

  ros::spin();
}
